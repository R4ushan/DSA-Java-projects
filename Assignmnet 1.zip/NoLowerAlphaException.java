public class NoLowerAlphaException extends Exception {
    public NoLowerAlphaException(String message) {
        super(message);
    }
}
