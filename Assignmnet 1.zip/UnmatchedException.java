public class UnmatchedException extends Exception {
    public UnmatchedException(String message){
        super(message);
    }
}
