public class InvalidSequenceException extends Exception {
    public InvalidSequenceException(String message) {
        super(message);
    }
}