public class NoSpecialCharacterException extends Exception {
    public NoSpecialCharacterException(String message) {
        super(message);
    }
}
