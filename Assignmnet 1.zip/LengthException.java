public class LengthException extends Exception {
    public LengthException(String message){
        super(message);
    }
}
