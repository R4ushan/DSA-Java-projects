import java.awt.Graphics;
import java.awt.Graphics2D;
import javax.swing.JComponent;

/**
   This component draws two car shapes.
*/
public class CarPanel extends JComponent
{  
	private Car car1;
	private int x,y, delay;
	private CarQueue carQueue;
	private int Direction;
	
	CarPanel(int x1, int y1, int d, CarQueue queue)
	{
		delay = d;
        x=x1;
        y=y1;
        car1 = new Car(x, y, this);
        carQueue = queue;
	}
	public void startAnimation()
	   {
	      class AnimationRunnable implements Runnable
	      {
	         public void run()
	         {
	            try
	            {
	            	for(int i = 0; i < 10; i++)
	               {
	            	   Direction = carQueue.deleteQueue();
	            	   int degree = 30;
	            	   
	            	   switch(Direction) {
	            	   case 0:
	            		   y = y - degree;
	            		   System.out.println("UP");
	            		   break;
	            	   case 1:
	            		   y = y + degree;
	            		   System.out.println("DOWN");
	            		   break;
	            	   case 2:
	            		   x = x + degree;
	            		   System.out.println("RIGHT");
	            		   break;
	            	   case 3:
	            		   x = x - degree;
	            		   System.out.println("LEFT");
	            		   break;
	            	   }
	            	   
	            	   if(y <= 0) {
	            		   y = 0;
	            		   System.out.println("Top Boundry");
	            		   repaint();
		            	   Thread.sleep(delay*500);
	            		   y = y + degree;
	            	   }
	            	   if(y >= 330) {
	            		   y = 330;
	            		   System.out.println("Bottom Boundry");
	            		   repaint();
		            	   Thread.sleep(delay*500);
	            		   y = y - degree;
	            	   }
	            	   if(x <= 0) {
	            		   x = 0;
	            		   System.out.println("LEFT Boundry");
	            		   repaint();
		            	   Thread.sleep(delay*500);
	            		   x = x + degree;
	            	   }
	            	   if(x >= 220) {
	            		   x = 220;
	            		   System.out.println("RIGHT Boundry");
	            		   repaint();
		            	   Thread.sleep(delay*500);
	            		   x = x - degree;
	            	   }
	            	   
	            	   carQueue.addToQueue();
	            	   
	            	   repaint();
	            	   Thread.sleep(delay*500);
	            	   
	               }
	            }
	            catch (InterruptedException exception)
	            {
	            	
	            }
	            finally
	            {
	            	
	            }
	         }
	      }
	      
	      Runnable r = new AnimationRunnable();
	      Thread t = new Thread(r);
	      t.start();
	   }
	
   public void paintComponent(Graphics g)
   {  
      Graphics2D g2 = (Graphics2D) g;

      car1.draw(g2,x,y);    
   }
}