/**
 *@author Raushan Oshan
 */

import java.util.ArrayList;
import java.util.Collections;

public class TownGraphManager implements TownGraphManagerInterface {

    private Graph<Town, Road> map;

    public TownGraphManager() {
        this.map = new Graph<>();
    }

    /**
     * Adds a road connecting two towns with a given road name and weight
     * @param town1 Name of town 1 (lastname, firstname)
     * @param town2 Name of town 2 (lastname, firstname)
     * @param weight The weight (distance or cost) of the road
     * @param roadName The name of the road
     * @return true if the road was added successfully, false otherwise
     */
    @Override
    public boolean addRoad(String town1, String town2, int weight, String roadName) {
        Town town1Obj = map.getTown(town1.hashCode());
        Town town2Obj = map.getTown(town2.hashCode());

        map.addEdge(town1Obj, town2Obj, weight, roadName);

        return map.containsEdge(town1Obj, town2Obj);
    }

    /**
     * Returns the name of the road that connects the two towns
     * @param town1 Name of town 1 (lastname, firstname)
     * @param town2 Name of town 2 (lastname, firstname)
     * @return the road name if the towns are connected, null otherwise
     */
    @Override
    public String getRoad(String town1, String town2) {
        for (Road road : map.returnRoadHashTable().values()) {
            if (isConnected(road, town1, town2)) {
                return road.getName();
            }
        }
        return null;
    }

    private boolean isConnected(Road road, String town1, String town2) {
        return (road.getSource().getName().equals(town1) && road.getDestination().getName().equals(town2)) ||
               (road.getSource().getName().equals(town2) && road.getDestination().getName().equals(town1));
    }

    /**
     * Adds a new town to the graph
     * @param townName Name of the town (lastname, firstname)
     * @return true if the town was added, false otherwise
     */
    @Override
    public boolean addTown(String townName) {
        Town newTown = new Town(townName);
        return map.addVertex(newTown);
    }

    /**
     * Retrieves the town with the specified name
     * @param townName The name of the town
     * @return The Town object if found, null otherwise
     */
    @Override
    public Town getTown(String townName) {
        for (Town town : map.vertexSet()) {
            if (town.getName().equals(townName)) {
                return town;
            }
        }
        return null;
    }

    /**
     * Checks if a town exists in the graph
     * @param townName Name of the town
     * @return true if the town exists, false otherwise
     */
    @Override
    public boolean containsTown(String townName) {
        return getTown(townName) != null;
    }

    /**
     * Checks if a road connection exists between two towns
     * @param town1 Name of town 1 (lastname, firstname)
     * @param town2 Name of town 2 (lastname, firstname)
     * @return true if the road exists, false otherwise
     */
    @Override
    public boolean containsRoadConnection(String town1, String town2) {
        Town town1Obj = getTown(town1);
        Town town2Obj = getTown(town2);
        return map.containsEdge(town1Obj, town2Obj);
    }

    /**
     * Returns a list of all road names sorted alphabetically
     * @return A list of all road names sorted by road name
     */
    @Override
    public ArrayList<String> allRoads() {
        ArrayList<String> roadNames = new ArrayList<>();
        for (Road road : map.returnRoadHashTable().values()) {
            roadNames.add(road.getName());
        }
        Collections.sort(roadNames);
        return roadNames;
    }

    /**
     * Deletes a road connection between two towns
     * @param town1 Name of town 1 (lastname, firstname)
     * @param town2 Name of town 2 (lastname, firstname)
     * @param roadName The name of the road
     * @return true if the road was successfully deleted, false otherwise
     */
    @Override
    public boolean deleteRoadConnection(String town1, String town2, String roadName) {
        Town town1Obj = getTown(town1);
        Town town2Obj = getTown(town2);

        if (map.containsEdge(town1Obj, town2Obj)) {
            map.removeEdge(town1Obj, town2Obj, 0, roadName);
            return true;
        }
        return false;
    }

    /**
     * Deletes a town from the graph
     * @param townName The name of the town
     * @return true if the town was successfully deleted, false otherwise
     */
    @Override
    public boolean deleteTown(String townName) {
        Town townToDelete = getTown(townName);
        return map.removeVertex(townToDelete);
    }

    /**
     * Returns a list of all towns in alphabetical order
     * @return A list of all towns sorted alphabetically by town name
     */
    @Override
    public ArrayList<String> allTowns() {
        ArrayList<String> townNames = new ArrayList<>();
        for (Town town : map.vertexSet()) {
            townNames.add(town.getName());
        }
        Collections.sort(townNames);
        return townNames;
    }

    /**
     * Returns the shortest path (sequence of roads) between two towns
     * @param town1 Name of town 1 (lastname, firstname)
     * @param town2 Name of town 2 (lastname, firstname)
     * @return A list of roads connecting the two towns, or null if no path exists
     */
    @Override
    public ArrayList<String> getPath(String town1, String town2) {
        Town sourceTown = getTown(town1);
        Town destinationTown = getTown(town2);

        return map.shortestPath(sourceTown, destinationTown);
    }
}