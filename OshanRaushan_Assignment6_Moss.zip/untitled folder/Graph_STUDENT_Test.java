/**
 *@author Raushan Oshan
 */

 import static org.junit.Assert.*;

 import java.util.ArrayList;
 
 import org.junit.After;
 import org.junit.Before;
 import org.junit.Test;
 
 /**
  * Test ALL methods of Graph class with a different set of data
  */
 
 public class Graph_STUDENT_Test {
 
     Graph<Town, Road> graphToTest;
     
     Town townA;
     Town townB;
     Town townC;
     Town townD;
     
     Road road1;
     Road road2;
     Road road3;
     Road road4;
     
     /**
      * @throws java.lang.Exception
      */
     @Before
     public void setUp() throws Exception {
         
         graphToTest = new Graph();
         
         townA = new Town("Springfield");
         townB = new Town("Shelbyville");
         townC = new Town("Ogdenville");
         townD = new Town("North Haverbrook");
         
         road1 = new Road(townA, townB, 3, "Main Street");
         road2 = new Road(townB, townC, 6, "Elm Road");
         road3 = new Road(townC, townD, 8, "Pine Avenue");
         road4 = new Road(townD, townA, 12, "Maple Drive");
         
         graphToTest.addVertex(townA);
         graphToTest.addVertex(townB);
         graphToTest.addVertex(townC);
         graphToTest.addVertex(townD);
         
         graphToTest.addEdge(townA, townB, 3, "Main Street");
         graphToTest.addEdge(townB, townC, 6, "Elm Road");
         graphToTest.addEdge(townC, townD, 8, "Pine Avenue");
         graphToTest.addEdge(townD, townA, 12, "Maple Drive");
     }
 
     @After
     public void tearDown() throws Exception {
         
         townA = null;
         townB = null;
         townC = null;
         townD = null;
         
         road1 = null;
         road2 = null;
         road3 = null;
         road4 = null;
     }
     
     @Test
     public void testAddEdge() {
         
         assertEquals(road1, graphToTest.getEdge(townA, townB));
         assertEquals(road2, graphToTest.getEdge(townB, townC));
         assertEquals(road3, graphToTest.getEdge(townC, townD));
         assertEquals(road4, graphToTest.getEdge(townD, townA));
     }
     
     @Test
     public void testGetEdge() {
         
         assertEquals(road1, graphToTest.getEdge(townA, townB));
         assertEquals(road2, graphToTest.getEdge(townB, townC));
         assertEquals(road3, graphToTest.getEdge(townC, townD));
         assertEquals(road4, graphToTest.getEdge(townD, townA));
     }
     
     @Test
     public void testAddVertex() {
         
         assertTrue(graphToTest.containsVertex(townA));
         assertTrue(graphToTest.containsVertex(townB));
         assertTrue(graphToTest.containsVertex(townC));
         assertTrue(graphToTest.containsVertex(townD));
     }
     
     @Test
     public void testContainsEdge() {
         
         assertTrue(graphToTest.containsEdge(townA, townB));
         assertTrue(graphToTest.containsEdge(townB, townC));
         assertTrue(graphToTest.containsEdge(townC, townD));
         assertTrue(graphToTest.containsEdge(townD, townA));
     }
     
     @Test
     public void testContainsVertex() {
         
         assertTrue(graphToTest.containsVertex(townA));
         assertTrue(graphToTest.containsVertex(townB));
         assertTrue(graphToTest.containsVertex(townC));
         assertTrue(graphToTest.containsVertex(townD));
     }
     
     @Test
     public void testRemoveEdge() {
         
         assertEquals(road1, graphToTest.removeEdge(townA, townB, 3, "Main Street"));
         assertEquals(road2, graphToTest.removeEdge(townB, townC, 6, "Elm Road"));
         assertEquals(road3, graphToTest.removeEdge(townC, townD, 8, "Pine Avenue"));
         assertEquals(road4, graphToTest.removeEdge(townD, townA, 12, "Maple Drive"));
     }
     
     @Test
     public void testRemoveVertex() {
         
         assertTrue(graphToTest.removeVertex(townA));
         assertTrue(graphToTest.removeVertex(townB));
         assertTrue(graphToTest.removeVertex(townC));
         assertTrue(graphToTest.removeVertex(townD));
     }
     
     @Test
     public void testShortestPath() {
         
         ArrayList<String> shortestPath = new ArrayList<>();
         shortestPath.add("Springfield via Maple Drive to North Haverbrook 12 mi");
         
         assertEquals(shortestPath, graphToTest.shortestPath(townA, townD));
     }
 }
 