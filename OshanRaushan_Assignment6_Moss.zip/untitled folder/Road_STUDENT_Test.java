/**
 *@author Raushan Oshan
 */
import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

public class Road_STUDENT_Test {

    private Town townA;
    private Town townB;
    private Town townC;
    private Road road1;
    private Road road2;
    private Road road3;

    @Before
    public void setUp() {
        townA = new Town("Springfield");
        townB = new Town("Shelbyville");
        townC = new Town("Ogdenville");

        road1 = new Road(townA, townB, 5, "Main Street");
        road2 = new Road(townA, townB, 5, "Main Street");
        road3 = new Road(townB, townC, 10, "Elm Road");
    }

    @Test
    public void testConstructorWithAllFields() {
        Road road = new Road(townA, townC, 7, "Highway");
        assertEquals(townA, road.getSource());
        assertEquals(townC, road.getDestination());
        assertEquals(7, road.getWeight());
        assertEquals("Highway", road.getName());
    }

    @Test
    public void testConstructorWithDefaultWeight() {
        Road road = new Road(townA, townC, "Main Street");
        assertEquals(1, road.getWeight());
    }

    @Test
    public void testContains() {
        assertTrue(road1.contains(townA));
        assertTrue(road1.contains(townB));
        assertFalse(road1.contains(townC));
    }

    @Test
    public void testToString() {
        assertEquals("Main Street", road1.toString());
    }

    @Test
    public void testCompareTo() {
        Road road4 = new Road(townA, townC, 7, "Highway");
        Road road5 = new Road(townA, townC, 5, "Main Street");

        assertTrue(road1.compareTo(road3) < 0); // road1 is lighter than road3
        assertTrue(road1.compareTo(road4) < 0); // road1 is lighter than road4
        assertEquals(0, road1.compareTo(road2)); // road1 and road2 have same weight
    }

    @Test
    public void testEquals() {
        assertTrue(road1.equals(road2)); // Same towns, same weight, same road name
        assertFalse(road1.equals(road3)); // Different destination town and weight
        assertFalse(road1.equals(null)); // Comparing with null
        assertFalse(road1.equals("String")); // Comparing with different class type
    }

    @Test
    public void testHashCode() {
        assertEquals(road1.hashCode(), road2.hashCode()); // road1 and road2 should have the same hash code
        assertNotEquals(road1.hashCode(), road3.hashCode()); // road1 and road3 should have different hash codes
    }
}
